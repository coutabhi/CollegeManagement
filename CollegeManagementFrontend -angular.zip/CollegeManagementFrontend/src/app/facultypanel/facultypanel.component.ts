import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-facultypanel',
  templateUrl: './facultypanel.component.html',
  styleUrls: ['./facultypanel.component.css']
})
export class FacultypanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
