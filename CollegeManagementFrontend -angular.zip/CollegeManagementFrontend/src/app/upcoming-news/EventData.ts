// event.model.ts
export interface EventData {
    id?: number;
    name: string;
    date: Date;
    location: string;
    description: string;
  }
  