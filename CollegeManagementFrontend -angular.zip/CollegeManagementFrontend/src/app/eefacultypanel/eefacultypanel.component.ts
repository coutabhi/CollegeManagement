import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eefacultypanel',
  templateUrl: './eefacultypanel.component.html',
  styleUrls: ['./eefacultypanel.component.css']
})
export class EefacultypanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
