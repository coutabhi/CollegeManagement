import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lib-panel',
  templateUrl: './lib-panel.component.html',
  styleUrls: ['./lib-panel.component.css']
})
export class LibPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
