
export interface Student {
    id: number;
    firstname: string;
    lastname: string;
    gender: string;
    branch: string;
    year: string;
    sem: string;
    mobileno: string;
    email: string;
    password: string;
  }
  