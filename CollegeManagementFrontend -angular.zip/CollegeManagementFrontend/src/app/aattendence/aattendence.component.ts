import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aattendence',
  templateUrl: './aattendence.component.html',
  styleUrls: ['./aattendence.component.css']
})
export class AattendenceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
