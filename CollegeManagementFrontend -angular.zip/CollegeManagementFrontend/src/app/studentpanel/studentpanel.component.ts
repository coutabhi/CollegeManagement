import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentpanel',
  templateUrl: './studentpanel.component.html',
  styleUrls: ['./studentpanel.component.css']
})
export class StudentpanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
