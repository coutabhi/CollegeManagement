import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eestudentpanel',
  templateUrl: './eestudentpanel.component.html',
  styleUrls: ['./eestudentpanel.component.css']
})
export class EestudentpanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
