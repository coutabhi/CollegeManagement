import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mesnotice',
  templateUrl: './mesnotice.component.html',
  styleUrls: ['./mesnotice.component.css']
})
export class MesnoticeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
