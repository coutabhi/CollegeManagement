import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cemarksheet',
  templateUrl: './cemarksheet.component.html',
  styleUrls: ['./cemarksheet.component.css']
})
export class CemarksheetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
